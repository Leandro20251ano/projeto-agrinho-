let truckX; // Posição do caminhão
let truckY = 200; // Altura fixa do caminhão
let truckSpeed = 2; // Velocidade do caminhão

function setup() {
  createCanvas(600, 400);
  // Começa no lado esquerdo, no campo
  truckX = 90;
}

function draw() {
  background(220);
  
  // Desenha o campo
  fill(34, 139, 34);
  ellipse(100, 200, 20, 20);
  text('Campo', 80, 190);
  
  // Desenha a cidade
  fill(0, 0, 255);
  ellipse(550, 200, 20, 20);
  text('Cidade', 530, 190);
  
  // Desenha a linha de conexão
  stroke(0);
  line(100, 200, 550, 200);
  
  // Desenha o caminhão
  fill(255, 0, 0);
  rect(truckX, truckY, 50, 20); // corpo do caminhão
  fill(0);
  ellipse(truckX + 10, truckY + 20, 10, 10); // roda esquerda
  ellipse(truckX + 30, truckY + 20, 10, 10); // roda direita
  
  // Move o caminhão em direção à cidade
  if (truckX < 550 - 40) { // até chegar perto da cidade
    truckX += truckSpeed;
  }
}